# Pastoral da Música — Paróquia Sagrada Família

Site da pastoral da Paróquia Sagrada Família, em Campo Mourão – PR. A página pública preserva o visual original, a biblioteca, a busca e a reprodução de áudio. HTML, CSS e JavaScript nativos são publicados na pasta `public`.

## Editar diretamente no site

Acesse **Área do administrador** no menu do site ou `/admin.html`. Entre com o e-mail e a senha da sua conta de administrador do site (a conta do painel da Netlify é separada).

Selecione uma celebração ou crie uma nova informando data e nome. Use **Adicionar música** para preencher título, momento litúrgico, tom, letra e cifra em texto. Você também pode enviar áudio (MP3, M4A, WAV ou OGG, até 20 MB), cifra em PDF e partitura em PDF (até 10 MB cada), ou informar links HTTPS. **Salvar e publicar** disponibiliza a atualização aos visitantes; recarregue a página pública para vê-la.

Clique em uma música da lista para editar ou excluir. Para substituir um arquivo, envie outro ou troque seu link. Para retirar um arquivo da música, apague o link. A exclusão remove o registro do repertório; arquivos enviados não são apagados automaticamente do armazenamento. Não envie conteúdo confidencial, pois os textos e arquivos publicados são públicos.

Se outra pessoa salvar a mesma música enquanto você edita, o painel recusa sobrescrever a alteração e solicita que você recarregue a lista. Copie os textos que deseja preservar antes de recarregar.

## Primeiro administrador

O serviço de login foi ativado. A criação do primeiro administrador exige configuração no painel da Netlify:

1. Abra o [projeto na Netlify](https://app.netlify.com/projects/website-upload-a0b281) e acesse **Identity**.
2. Use **Invite users** para convidar seu e-mail. Abra o link recebido para definir sua senha no site.
3. Na lista de usuários do Identity, abra sua conta, adicione a função `admin` em **Roles** e salve. Entre novamente no site.

Somente contas com a função `admin`, controlada pelo servidor, podem gravar ou enviar arquivos. A área pública continua disponível sem login. O painel oferece recuperação de senha e aceita os links de convite, confirmação e recuperação. Como medida de organização, o cadastro do Identity pode ser alterado para **Invite only** no painel da Netlify.

## Armazenamento e publicação

Os repertórios e músicas são persistidos no Netlify Database, usando Drizzle e o esquema `db/schema.ts`. As migrações ficam em `netlify/database/migrations` e são aplicadas na publicação. A primeira migração mantém as duas celebrações originais, sem inventar músicas.

Áudios e PDFs ficam no Netlify Blobs, separados dos registros do banco. As rotas `/api/*` são atendidas pelo Netlify Server em `netlify/server/index.mjs`, com Node.js 24. O serviço verifica a sessão no provedor de identidade e a função de administrador em todas as operações protegidas. A dependência de autenticação do navegador está em `public/vendor/identity.js` (`@netlify/identity` 2.0.1), distribuída como módulo para navegador, sem depender de um CDN durante o uso do site.

O array `REPERTORIOS` em `public/index.html` conserva o conteúdo original como alternativa quando o serviço online está indisponível. Depois da publicação, faça as atualizações pelo painel: a versão online do banco tem precedência sobre esse array.

## Desenvolvimento e verificações

Instale as dependências com `npm install` e use `netlify dev --port 8889` para os recursos locais disponíveis na plataforma. O Identity deve ser validado em uma publicação, pois não é emulado localmente. Abrir apenas o HTML permite visualizar a página original, mas não disponibiliza o banco ou o painel de edição.

Execute `node --test tests/admin.test.mjs` para verificar bloqueios de acesso, origem das requisições, autorização de administrador e escape dos textos. Não há etapa de compilação do frontend.
