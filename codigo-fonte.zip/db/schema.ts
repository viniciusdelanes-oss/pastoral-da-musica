import { pgTable, text, uuid, integer } from 'drizzle-orm/pg-core';
export const celebracoes = pgTable('celebracoes', {
  id: uuid().defaultRandom().primaryKey(),
  data: text().notNull().unique(),
  celebracao: text().notNull(),
});
export const musicas = pgTable('musicas', {
  id: uuid().defaultRandom().primaryKey(),
  repertorio: uuid().notNull().references(() => celebracoes.id, { onDelete: 'cascade' }),
  titulo: text().notNull(), momento: text().notNull(), tom: text().notNull().default(''),
  letra: text().notNull().default(''), cifraTexto: text('cifra_texto').notNull().default(''),
  audio: text().notNull().default(''), cifra: text().notNull().default(''),
  partitura: text().notNull().default(''), versao: integer().notNull().default(1),
});
