import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import handler from '../netlify/server/index.mjs';
const origin = 'https://website-upload-a0b281.netlify.app';

test('edição sem login é recusada antes de acessar o banco', async () => {
  for (const [path,method] of [['/api/repertorios','POST'],['/api/musicas/123','PUT'],['/api/musicas/123','DELETE'],['/api/arquivos?ext=pdf','POST']]) {
    const response = await handler(new Request(origin+path,{method,headers:{origin}}));
    assert.equal(response.status,401);
  }
});
test('origem de outro site é recusada', async () => {
  const response=await handler(new Request(origin+'/api/repertorios',{method:'POST',headers:{origin:'https://outro.example'}}));
  assert.equal(response.status,403);
});
test('função admin vem dos metadados controlados pelo servidor', async () => {
  const original=globalThis.fetch;
  try {
    for(const [data,status] of [[{user_metadata:{roles:['admin']}},403],[{app_metadata:{roles:['member']}},403],[{app_metadata:{roles:['admin']}},200]]) {
      globalThis.fetch=async()=>Response.json(data);
      const response=await handler(new Request(origin+'/api/admin',{headers:{cookie:'nf_jwt=credencial-ficticia-para-teste'}}));
      assert.equal(response.status,status);
    }
    globalThis.fetch=async()=>new Response('',{status:401});
    assert.equal((await handler(new Request(origin+'/api/admin',{headers:{cookie:'nf_jwt=credencial-ficticia-para-teste'}}))).status,401);
  } finally { globalThis.fetch=original; }
});
test('letra e cifra são escapadas antes de inserir HTML', () => {
  const html=readFileSync('public/index.html','utf8');
  const code=html.slice(html.indexOf("const esc="),html.indexOf('const hoje='));
  const context=vm.createContext({MOMENTOS:[],PASTA_AUDIO:'',PASTA_CIFRA:'',PASTA_PARTITURA:''});
  vm.runInContext(code,context);
  const rendered=vm.runInContext(`linhaHTML({titulo:'<img src=x onerror=alert(1)>',letra:'<script>alert(1)</script>',cifraTexto:'<b>Am</b>'})`,context);
  assert.ok(!rendered.includes('<script>'));
  assert.ok(!rendered.includes('<img'));
  assert.ok(rendered.includes('&lt;b&gt;Am&lt;/b&gt;'));
  assert.equal(vm.runInContext("urlDe('musicas/audio/','/api/arquivos/123.mp3')",context),'/api/arquivos/123.mp3');
});
