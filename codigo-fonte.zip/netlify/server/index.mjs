import { drizzle } from 'drizzle-orm/netlify-db';
import { eq, and, sql } from 'drizzle-orm';
import { getStore } from '@netlify/blobs';
import { randomUUID } from 'node:crypto';
import { celebracoes, musicas } from '../../db/schema.ts';
const db = drizzle();
const identityURL = 'https://website-upload-a0b281.netlify.app/.netlify/identity';
const json = (value, status = 200) => Response.json(value, { status, headers: { 'Cache-Control': 'no-store' } });
const fail = (message, status = 400) => { throw Object.assign(new Error(message), { status }); };
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const extensions = { pdf: 'application/pdf', mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav', ogg: 'audio/ogg' };
export const config = { path: '/api/*' };
async function admin(req) {
  const token = req.headers.get('cookie')?.split(';').map(x => x.trim()).find(x => x.startsWith('nf_jwt='))?.slice(7);
  if (!token) fail('Entre com sua conta de administrador.', 401);
  const response = await fetch(`${identityURL}/user`, { headers: { Authorization: `Bearer ${token}` } });
  if (!response.ok) fail('Sua sessão expirou. Entre novamente.', 401);
  const user = await response.json();
  if (!Array.isArray(user.app_metadata?.roles) || !user.app_metadata.roles.includes('admin')) fail('Esta conta não tem permissão de administrador.', 403);
  return user;
}
function text(value, max, required = false) {
  if (typeof value !== 'string' || value.length > max || (required && !value.trim())) fail('Confira os campos e seus limites.');
  return value.trim();
}
function link(value) {
  const result = text(value ?? '', 2000);
  if (result && !/^https:\/\/[^\s]+$/i.test(result) && !/^\/api\/arquivos\/[a-f0-9-]+\.(pdf|mp3|m4a|wav|ogg)$/.test(result)) fail('Use um link HTTPS ou envie um arquivo.');
  return result;
}
export default async function handler(req) {
  try {
    const url = new URL(req.url), path = url.pathname;
    if (req.method === 'GET' && path === '/api/repertorios') {
      const reps = await db.select().from(celebracoes).orderBy(celebracoes.data);
      const songs = await db.select().from(musicas).orderBy(musicas.titulo);
      return json(reps.map(r => ({ ...r, musicas: songs.filter(s => s.repertorio === r.id) })));
    }
    if (req.method === 'GET' && path.startsWith('/api/arquivos/')) {
      const key = path.slice('/api/arquivos/'.length), ext = key.split('.').pop();
      if (!/^[a-f0-9-]{36}\.(pdf|mp3|m4a|wav|ogg)$/.test(key)) return json({ error: 'Arquivo inválido.' }, 404);
      const body = await getStore({ name: 'musica-arquivos', consistency: 'strong' }).get(key, { type: 'stream' });
      return body ? new Response(body, { headers: { 'Content-Type': extensions[ext], 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'public, max-age=3600', 'Content-Disposition': `inline; filename="${key}"` } }) : json({ error: 'Arquivo não encontrado.' }, 404);
    }
    // Todas as operações de escrita verificam a sessão e a função no provedor.
    if (req.method !== 'GET') {
      const origin = req.headers.get('origin');
      if (!origin || origin !== url.origin) fail('Origem inválida.', 403);
    }
    await admin(req);
    if (path === '/api/admin' && req.method === 'GET') return json({ admin: true });
    if (path === '/api/arquivos' && req.method === 'POST') {
      const ext = url.searchParams.get('ext');
      if (!extensions[ext]) fail('Envie PDF, MP3, M4A, WAV ou OGG.');
      const limit = ext === 'pdf' ? 10 * 1024 * 1024 : 20 * 1024 * 1024;
      if (Number(req.headers.get('content-length')) > limit) fail('Arquivo acima do limite.', 413);
      const reader = req.body?.getReader();
      if (!reader) fail('Selecione um arquivo.');
      const chunks = []; let size = 0;
      while (true) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > limit) { await reader.cancel(); fail('Arquivo acima do limite.', 413); } chunks.push(Buffer.from(value)); }
      const data = Buffer.concat(chunks);
      const signature = data.subarray(0, 12).toString('latin1');
      const valid = ext === 'pdf' ? signature.startsWith('%PDF-') : ext === 'mp3' ? signature.startsWith('ID3') || (data[0] === 255 && (data[1] & 224) === 224) : ext === 'm4a' ? signature.slice(4, 8) === 'ftyp' : ext === 'ogg' ? signature.startsWith('OggS') : signature.startsWith('RIFF') && signature.slice(8) === 'WAVE';
      if (!size || !valid) fail('O conteúdo do arquivo não corresponde ao formato informado.');
      const key = `${randomUUID()}.${ext}`;
      await getStore({ name: 'musica-arquivos', consistency: 'strong' }).set(key, data);
      return json({ url: `/api/arquivos/${key}` }, 201);
    }
    const payload = req.method === 'POST' || req.method === 'PUT' ? await req.json() : {};
    if (path === '/api/repertorios' && req.method === 'POST') {
      const data = text(payload.data, 10, true), celebracao = text(payload.celebracao, 200, true);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !Number.isFinite(Date.parse(data)) || new Date(data).toISOString().slice(0, 10) !== data) fail('Informe uma data válida.');
      return json((await db.insert(celebracoes).values({ data, celebracao }).returning())[0], 201);
    }
    const id = path.split('/').pop();
    if (!uuid.test(id)) return json({ error: 'Caminho não encontrado.' }, 404);
    if (path.startsWith('/api/musicas/')) {
      if (req.method === 'DELETE') {
        const rows = await db.delete(musicas).where(and(eq(musicas.id, id), eq(musicas.versao, Number(url.searchParams.get('versao'))))).returning();
        if (!rows.length) fail('A música foi alterada. Recarregue antes de excluir.', 409);
        return json({ ok: true });
      }
      if (req.method === 'PUT') {
        if (!uuid.test(payload.repertorio)) fail('Selecione uma celebração.');
        const values = { repertorio: payload.repertorio, titulo: text(payload.titulo, 200, true), momento: text(payload.momento, 80, true), tom: text(payload.tom ?? '', 40), letra: text(payload.letra ?? '', 50000), cifraTexto: text(payload.cifraTexto ?? '', 50000), audio: link(payload.audio), cifra: link(payload.cifra), partitura: link(payload.partitura) };
        if (payload.nova === true) return json((await db.insert(musicas).values({ id, ...values }).returning())[0], 201);
        const rows = await db.update(musicas).set({ ...values, versao: sql`${musicas.versao} + 1` }).where(and(eq(musicas.id, id), eq(musicas.versao, payload.versao))).returning();
        if (!rows.length) fail('Outra edição foi salva. Recarregue a lista antes de editar novamente.', 409);
        return json(rows[0]);
      }
    }
    return json({ error: 'Caminho não encontrado.' }, 404);
  } catch (error) {
    if (error.code === '23505' || error.cause?.code === '23505') return json({ error: 'Já existe um cadastro com essa data ou identificador.' }, 409);
    return json({ error: error.status ? error.message : 'Não foi possível concluir. Tente novamente.' }, error.status || 500);
  }
}
